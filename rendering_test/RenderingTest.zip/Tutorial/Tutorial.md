# Rendering Test Tutorial

---

## Installing Unity

This rendering test was developed using the Unity Engine, so it will be needed for executing it.

You can find the download link and install instructions for Unity on their website: https://unity.com/

Preferably use a version of Unity 2019.1.

---

## Testing your Material

    This tutorial will consider that a compatible Unity version is already installed through Unity Hub

* Open Unity Hub.
* Add your project through the 'Add' button.
* Select the project folder.
* Now click on the added project to open it.

![](./Images/tutorial1.jpg)

* Unity will import assets, this may take a while.
* With Unity open you will notice the 'Project' tab at the bottom of the screen.
* Select the "Scenes" folder and double-click the 'testscene'.
* Wait for Unity to load the scene. 

![](./Images/tutorial2.jpg)

* Now select the "Materials/Textures" folder on the 'Project' tab.
* Drag and drop the generated textures into the panel to the side.

![](./Images/tutorial3.jpg)

* Unity will import the textures.
* Now, still on the "Textures" folder, select your Normal map.
* On the 'Inspector' tab (right of the screen) set 'Texture Type' to 'Normal map'

![](./Images/tutorial4.jpg)

* Now select 'test_material' inside "Materials" folder.
* Select your files for the following fields in 'Surface Inputs'.
    - Select your tiling texture for the 'Base Map'.
    - Select your height map for the 'Height Map'.
    - Select your normal map for the 'Normal Map'.
    - Select your converted roughness map (conversion program provided in the "sources" folder in GitHub repository, more information on "tutorials" folder) for the 'Mask Map'.

![](./Images/tutorial5.jpg)

* Now you can better see your material in the 'Game' tab.
* Press the 'Play' button at the center top of the screen (If you want fullscreen, mark 'Maximize on Play' on the 'Game' tab before).

![](./Images/tutorial6.jpg)

* DONE! Now you can see an animation showing variation of light in your texture.
* Press 'Play' again to stop.

---

## Extra

Sometimes it's better to have a in-engine tool to increase or decrease the strength of your height, normal and roughness maps instead of directly changing the texture.

To do this in Unity:

* Select the 'test_material'.
* Go to 'Surface Inputs'.
* Customize the following fields:
  - 'Metallic' if you want to change how metallic is your surface (Note that this can only decrease the level of metalicity, if you need a higher level you will have to change it in the Red channel of the texture).
  - 'Smoothness Remapping' if you want to change the roughness.
  - The slider next to 'Normal Map' if you want to change the strength of the normals.
  - 'Amplitude (cm)' if you want to change the strength of the Height map.

![](./Images/tutorial-extra.jpg)