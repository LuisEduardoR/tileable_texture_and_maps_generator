# Rendering Test Tutorial

## Installing Unity

This rendering test was developed using the Unity Engine, so it will be needed for excuting it.

You can find the download link and install instructions for Unity on their website: https://unity.com/

Preferably use a version of Unity 2019.1.

## Testing your Material

    This tutorial will consider that Unity was installed through Unity Hub

* Open Unity Hub.
* Add your project through the 'Add' button.
* Select the project folder.
* Now click on the added project to open it.

![](./Images/tutorial1.jpg)

* Unity will import assets, this may take a while.
* With Unity open you will notice the 'Project' tabs at the bottom of the screen.
* Select the "Materials/Textures" folder on the 'Project' tab.
* Drag and drop the generated textures into the panel to the side.

![](./Images/tutorial2.jpg)

* Unity will import the textures.
* Now select the Normal texture and on the 'Inspector' (right of the screen) tab set 'Texture Type' to 'Normal map'

![](./Images/tutorial3.jpg)

* Now select 'test_material' inside "Materials" folder.
* Select your files for the following fields in 'Surface Inputs'.
    - Select your tiling texture for the 'Base Map'.
    - Select your height map for the 'Height Map'.
    - Select your normal map for the 'Normal Map'.
    - Select your converted roughness map (conversion program provided in the "sources" folder in GitHub repository, more information on "tutorials" folder) for the 'Mask Map'.

![](./Images/tutorial4.jpg)

* Now you can already see your material in the 'Game tab'.
* Press the Play button at center top of the screen (Mark the 'Maximize on Play' button on the 'Game' tab for fullscreen).
* DONE! Now you can see an animation showing variation of light in your texture.
* Press Play again to stop.