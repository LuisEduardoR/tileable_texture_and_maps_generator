﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotation : MonoBehaviour
{

    [SerializeField] float angularVelocity = 90f;

    void FixedUpdate()
    {

        transform.Rotate(0, angularVelocity * Time.fixedDeltaTime, 0);

    }
}
